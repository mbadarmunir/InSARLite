# pipeInSAR

To run the GUI, Please run following
import pipeinsar
pipeinsar.main()